package com.sample.order.sampleorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleorderApplicationTests {

	@Test
	void contextLoads() {
	}

}
