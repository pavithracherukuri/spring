package com.example.cloudgate.samplecloudgate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamplecloudgateApplicationTests {

	@Test
	void contextLoads() {
	}

}
