package com.example.cloudgate.samplecloudgate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamplecloudgateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SamplecloudgateApplication.class, args);
	}

}
