package com.sample.customer.samplecustomer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamplecustomerApplicationTests {

	@Test
	void contextLoads() {
	}

}
