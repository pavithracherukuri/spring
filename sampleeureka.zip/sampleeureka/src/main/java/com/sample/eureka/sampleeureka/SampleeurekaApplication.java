package com.sample.eureka.sampleeureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleeurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleeurekaApplication.class, args);
	}

}
