package com.sample.eureka.sampleeureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleeurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
